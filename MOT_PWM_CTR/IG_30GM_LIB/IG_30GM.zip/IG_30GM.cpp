#include "IG_30GM.h"

// Initialize the static instance pointer
IG_30GM* IG_30GM::_instance = nullptr;


// Use member initializer list for initialization instead of assignment in the body.
// This is more efficient and the C++ standard way.
IG_30GM::IG_30GM(int pin) : _pin(pin)
{
    // The static pointer is set to this instance.
    _instance = this;
}



IG_30GM::~IG_30GM()
{
}


void IG_30GM::init() // The 'interrupt_input' parameter is removed as we now use _pin from the constructor.
{

    byte error, address;
    int nDevices;
    


    int interrupt_input = _pin; // Use the member variable
    


    Wire.begin();
    Serial.begin(9600);
    

    
    Serial.println("\nI2C Scanner");
    while (!Serial);             // Leonardo: wait for serial monitor
    Serial.println("Scanning...");  



    nDevices = 0;

    for(address = 1; address < 127; address++ ) 
    {
    // The i2c_scanner uses the return value of
    // the Write.endTransmisstion to see if
    // a device did acknowledge to the address.
        Wire.beginTransmission(address);
        error = Wire.endTransmission();



        if (error == 0)
        {
            Serial.print("I2C device found at address 0x");
            if (address<16) 
            Serial.print("0");

            _lcd_addr = address ; 
            Serial.print(_lcd_addr,HEX);
            Serial.println("  !");

            nDevices++;
        }
        else if (error==4) 
        {
            Serial.print("Unknow error at address 0x");
            if (address<16) 
            Serial.print("0");
            Serial.println(address,HEX);
        }    
    }


    if (nDevices == 0)
    Serial.println("No I2C devices found\n");
    else
    Serial.println("done\n");



    delay(1000);
            // wait 1 seconds for next scan


////////////////////////////////



///////////////// lcd 시작

    LiquidCrystal_I2C lcd(_lcd_addr, _lcd_cols, _lcd_rows);



    lcd.begin();
    lcd.clear();
    lcd.home();
    lcd.print("Loading...");

    
    pinMode(interrupt_input , INPUT_PULLUP);
    

    
    Serial.println("RPM Measurement Start");
    Serial.println("인터럽트 설정 완료. 핀 3의 펄스 수를 세고 있습니다.");

    // Attach the static wrapper function as the ISR.
    // The pin is now correctly using the member variable.
    attachInterrupt(digitalPinToInterrupt(interrupt_input), _isr_wrapper, FALLING);


    
    delay(1000); 

}

// This is the static function that the C-style attachInterrupt can call.
void IG_30GM::_isr_wrapper() 
{
  if (_instance) 
  {
    _instance->_interrupt_handler();
  }
}

// This is the actual instance-specific interrupt handler.
void IG_30GM::_interrupt_handler() 
{
  _elapsedTime = micros() - _startTime;
  _startTime = micros();
}



void IG_30GM::lcd_show_rpm()
{
  double now_pulsecount;
  long double rpm ;



  uint8_t rpm_array_count = 0 ;
  int rpm_array[AVG_COUNT_NUM];
  float rpm_avg =0;



  uint8_t pulse_array_count = 0;
  int pulse_array[AVG_COUNT_NUM];
  float pulse_avg = 0;


  LiquidCrystal_I2C lcd(_lcd_addr, _lcd_cols, _lcd_rows);



  lcd.clear();
  lcd.home();


  
  now_pulsecount = (double)1/((float)_elapsedTime/1000000);





  Serial.print("펄스 주기 (마이크로초): ");
  Serial.println(_elapsedTime);

  Serial.print("1초간 펄스 수: ");
  Serial.println(now_pulsecount);
  
  rpm = now_pulsecount * 60 / (_ENCODER_PPR)/71;

    
  pulse_array[pulse_array_count%AVG_COUNT_NUM] = now_pulsecount;

  pulse_array_count++;
  

  pulse_avg = 0 ;

  for(int i =0 ; i <AVG_COUNT_NUM ; i++)
  {
    pulse_avg +=pulse_array[i];
  }
  pulse_avg = pulse_avg/AVG_COUNT_NUM;



  Serial.print("펄스주기 평균 :");    
  Serial.println(pulse_avg);











  rpm_array[rpm_array_count%AVG_COUNT_NUM] = rpm;
  rpm_array_count++;


  rpm_avg = 0 ;
  for(int i =0 ; i <AVG_COUNT_NUM ; i++)
  {
    rpm_avg +=rpm_array[i];
  }
  rpm_avg = rpm_avg/AVG_COUNT_NUM;




    Serial.print("RPM:");    
    Serial.println(rpm_avg);



  if (rpm > 0) {
    
    lcd.print("ENC_PUL:");   
    lcd.print(pulse_avg);
    
    lcd.setCursor(0,1);

    lcd.print("RPM : ");
    lcd.print(rpm_avg);
  }


  delay(400); // 1초 대기



  
}