#ifndef IG_30GM_h
#define IG_30GM_h



#define AVG_COUNT_NUM 20

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>




class IG_30GM
{
private:
    
    int _pin;
    const int _ENCODER_PPR = 13;
    
    // --- LCD Properties ---
    // These are configured in the init() function
    uint8_t _lcd_addr; // Will be found by the I2C scanner
    uint8_t _lcd_cols = 16;
    uint8_t _lcd_rows = 2;

    // --- Interrupt & RPM Calculation Data ---
    // 'volatile' is crucial here because these are modified by an ISR
    volatile unsigned long _startTime = 0;
    volatile unsigned long _elapsedTime = 0;

    // --- For calculating a moving average of RPM to smooth out readings ---
    uint8_t _rpm_array_count = 0;
    float _rpm_array[AVG_COUNT_NUM]{}; // Initialize all elements to 0
    float _rpm_avg = 0.0f;
    
    // The ISR function is now a private member
    void _interrupt_handler();

    // Static pointer to the current instance to be used in the static ISR wrapper
    static IG_30GM* _instance;


public:


    
	/**
	 * Constructor
	 *
	 * @param pin	I2C slave address of the LCD display. Most likely printed on the
	 *					LCD circuit board, or look in the supplied LCD documentation.
	 * 
	 */
    IG_30GM(int pin);

    ~IG_30GM();


	/**
	 *
	 * @param interrupt_input	
     * 
     *  -> 펄스로 입력할 핀 넘버
	 */

    void init();

    // Static wrapper function to be passed to attachInterrupt
    static void _isr_wrapper();


};


#endif